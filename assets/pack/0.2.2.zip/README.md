# Important Minecraft Settings
**For the best playing experience, use the following *highly reccommended* Minecraft settings.** <br>
**The [Optifine](https://optifine.net/downloads) mod is also extremely encouraged.**

### Turn Connected Textures OFF
> Options > Video Settings > Quality
### Turn Smooth Lighting OFF
> Options > Video Settings
### OptiFine: Turn OFF Lazy Chunk Loading
> Options > Performance
### Optimal Render Distance: 15
> Options > Video Settings
### Minimum Entity Distance: 200%
> Options > Video Settings > Details
